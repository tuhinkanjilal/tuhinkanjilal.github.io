# Check if running as administrator
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    # Relaunch the script as administrator
    Start-Process powershell.exe -Verb RunAs -ArgumentList "-File",$MyInvocation.MyCommand.Path
    # Exit the current session
    Exit
}
 
# Execute gPLinkReport, filter out entries with blank Precedence and DisplayName "[GPOADmin Working Copy]", sort by Precedence, and display in Out-GridView
gPLinkReport | Where-Object { $_.Precedence -ne "" -and $_.DisplayName -ne "[GPOADmin Working Copy]" -and $_.Precedence -ne $null } | Select Precedence, DisplayName, CanonicalName, LinkEnabled, Enforced, GPOStatus, CreationTime, ModificationTime | Sort-Object Precedence | Out-GridView
 
# Pause to keep the window open
Pause