 
Add-Type -AssemblyName System.Windows.Forms
 
# Create form
$form = New-Object System.Windows.Forms.Form
$form.Text = "Group Policy Details"
$form.Size = New-Object System.Drawing.Size(400,200)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = 'FixedSingle'
 
# Create label and text box for keyword search
$labelKeyword = New-Object System.Windows.Forms.Label
$labelKeyword.Location = New-Object System.Drawing.Point(10,20)
$labelKeyword.Size = New-Object System.Drawing.Size(100,20)
$labelKeyword.Text = "Enter Keyword:"
$form.Controls.Add($labelKeyword)
 
$textboxKeyword = New-Object System.Windows.Forms.TextBox
$textboxKeyword.Location = New-Object System.Drawing.Point(120,20)
$textboxKeyword.Size = New-Object System.Drawing.Size(200,20)
$form.Controls.Add($textboxKeyword)
 
# Create button to search for policies
$buttonSearch = New-Object System.Windows.Forms.Button
$buttonSearch.Location = New-Object System.Drawing.Point(120,60)
$buttonSearch.Size = New-Object System.Drawing.Size(100,30)
$buttonSearch.Text = "Search"
$buttonSearch.Add_Click({
    $keyword = $textboxKeyword.Text
    if ($keyword -ne "") {
        try {
            $matchingGPOs = Get-GPO -All | Where-Object { $_.DisplayName -like "*$keyword*" }
            if ($matchingGPOs) {
                $resultsForm = New-Object System.Windows.Forms.Form
                $resultsForm.Text = "Matching Group Policies"
                $resultsForm.Size = New-Object System.Drawing.Size(600,400)
                $resultsForm.StartPosition = "CenterScreen"
                $resultsForm.FormBorderStyle = 'FixedSingle'
                
                $listBoxResults = New-Object System.Windows.Forms.ListBox
                $listBoxResults.Location = New-Object System.Drawing.Point(10,10)
                $listBoxResults.Size = New-Object System.Drawing.Size(580, 300)
                $listBoxResults.DisplayMember = "DisplayName"
                
                foreach ($gpo in $matchingGPOs) {
                    $listBoxResults.Items.Add($gpo)
                }
                
                $resultsForm.Controls.Add($listBoxResults)
                
                $listBoxResults.Add_SelectedIndexChanged({
                    $selectedGPO = $listBoxResults.SelectedItem
                    $selectedGPOReport = Get-GPOReport -Name $selectedGPO.DisplayName -ReportType Html
                    # Modify HTML content to change font color
                    #$selectedGPOReport = $selectedGPOReport -replace '</head>', '<style>body { color: black; }</style></head>'
                    
                    $ou = $selectedGPO.OrganizationalUnit
                    $priority = $selectedGPO.GpoStatus
                    $detailsForm = New-Object System.Windows.Forms.Form
                    $detailsForm.Text = "$($selectedGPO.DisplayName) Details"
                   # $detailsForm.Size = New-Object System.Drawing.Size(800,400)
                    $detailsForm.WindowState = "Maximized"
                   # $detailsForm.StartPosition = "CenterScreen"
                    $detailsForm.FormBorderStyle = 'FixedSingle'
                    
                    $webBrowser = New-Object System.Windows.Forms.WebBrowser
                    $webBrowser.Location = New-Object System.Drawing.Point(10,10)
                    $webBrowser.Size = New-Object System.Drawing.Size(880, 800)
                    $webBrowser.DocumentText = $selectedGPOReport
                    $detailsForm.Controls.Add($webBrowser)
                    
                    $labelOU = New-Object System.Windows.Forms.Label
                    $labelOU.Location = New-Object System.Drawing.Point(10,440)
                    $labelOU.Size = New-Object System.Drawing.Size(780,20)
                    $labelOU.Text = "Assigned OU: $ou"
                    $detailsForm.Controls.Add($labelOU)
                    
                    $labelPriority = New-Object System.Windows.Forms.Label
                    $labelPriority.Location = New-Object System.Drawing.Point(10,820)
                    $labelPriority.Size = New-Object System.Drawing.Size(780,20)
                    $labelPriority.Text = "Priority: $priority"
                    $detailsForm.Controls.Add($labelPriority)
                    
                    $detailsForm.ShowDialog() | Out-Null
                })
                
                $resultsForm.Controls.Add($listBoxResults)
                $resultsForm.ShowDialog() | Out-Null
            } else {
                [System.Windows.Forms.MessageBox]::Show("No matching Group Policies found.", "Information", "OK", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
            }
        } 
        catch {
            [System.Windows.Forms.MessageBox]::Show("Error: $_", "Error", "OK", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Please enter a keyword.", "Error", "OK", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
})
$form.Controls.Add($buttonSearch)
 
# Show form
$form.ShowDialog() | Out-Null